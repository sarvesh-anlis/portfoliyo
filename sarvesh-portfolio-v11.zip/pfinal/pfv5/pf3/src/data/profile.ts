/**
 * Single source of truth for personal details & links.
 * Every section (hero, contact, footer) reads from here, so a link only
 * ever needs to be fixed in ONE place.
 *
 * GitHub & LinkedIn URLs are taken from the hyperlinks inside the resume PDF.
 */
export const PROFILE = {
  name: "Sarvesh Kumar R.M",
  shortName: "Sarvesh Kumar",
  title: "Aspiring Data Analyst",
  email: "sarveshkumar.analytics@gmail.com",
  phone: "+91 9150185160",
  phoneHref: "tel:+919150185160",
  location: "Cuddalore, Tamil Nadu",
  resume: "/resume.pdf",
  resumeFileName: "Sarvesh_Kumar_RM_Data_Analyst_Resume.pdf",

  website: "https://sarveshkumarrm.netlify.app",
  websiteLabel: "sarveshkumarrm.netlify.app",

  github: "https://github.com/sarveshkumaranalytics",
  githubLabel: "github.com/sarveshkumaranalytics",

  linkedin: "https://www.linkedin.com/in/sarvesh-kumar-r-m-504707402",
  linkedinLabel: "linkedin.com/in/sarvesh-kumar-r-m",
} as const;

export const mailto = `mailto:${PROFILE.email}?subject=${encodeURIComponent("Data Analyst opportunity")}`;
/** Opens Gmail's web composer — works even when no desktop mail app is set up. */
export const gmailCompose = `https://mail.google.com/mail/?view=cm&fs=1&to=${PROFILE.email}&su=${encodeURIComponent("Data Analyst opportunity")}`;
