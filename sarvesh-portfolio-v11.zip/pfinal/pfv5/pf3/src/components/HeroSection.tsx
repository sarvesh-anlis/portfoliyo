import { ArrowDown, Mail, MapPin, Sparkles, Download, Github, Linkedin, Trophy, BarChart3, Play, Loader2 } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { PROFILE, mailto } from "@/data/profile";

const stats = [
  { value: "1", label: "Internship" },
  { value: "4", label: "Projects" },
  { value: "2", label: "Prize Wins" },
  { value: "7.3", label: "CGPA" },
];

// What raw data becomes — typed after "raw data →"
const outcomes = ["clean datasets", "SQL insights", "Power BI dashboards", "clear reports", "better decisions"];

const socials = [
  { icon: Github, href: PROFILE.github, label: "GitHub" },
  { icon: Linkedin, href: PROFILE.linkedin, label: "LinkedIn" },
  { icon: Mail, href: mailto, label: "Email" },
];

/* Syntax-coloured tokens for the SQL card */
const K = ({ c }: { c: string }) => <span style={{ color: "hsl(199 89% 68%)" }}>{c}</span>;  // keyword
const S = ({ c }: { c: string }) => <span style={{ color: "hsl(95 45% 66%)" }}>{c}</span>;   // string
const N = ({ c }: { c: string }) => <span style={{ color: "hsl(30 90% 66%)" }}>{c}</span>;   // number
const C = ({ c }: { c: string }) => <span style={{ color: "hsl(210 10% 52%)" }}>{c}</span>;  // comment

const queryLines: JSX.Element[] = [
  <C key="c" c="-- find_the_right_analyst.sql" />,
  <><K c="SELECT" /> *</>,
  <><K c="FROM" /> candidates</>,
  <><K c="WHERE" /> role = <S c="'Data Analyst'" /></>,
  <>{"  "}<K c="AND" /> skills <K c="LIKE" /> <S c="'%SQL%'" /></>,
  <>{"  "}<K c="AND" /> skills <K c="LIKE" /> <S c="'%Power BI%'" /></>,
  <><K c="ORDER BY" /> curiosity <K c="DESC" /></>,
  <><K c="LIMIT" /> <N c="1" />;</>,
];

const resultRows: [string, string][] = [
  ["name", PROFILE.name],
  ["role", "Aspiring Data Analyst"],
  ["skills", "SQL, Python, Power BI, Excel"],
  ["education", "B.E. CSE · 2027"],
  ["currently", "Intern @ VIPS Tech"],
];

const HeroSection = () => {
  const [idx, setIdx] = useState(0);
  const [displayed, setDisplayed] = useState("");
  const [deleting, setDeleting] = useState(false);
  const [visibleLines, setVisibleLines] = useState(0);
  const [phase, setPhase] = useState<"typing" | "running" | "done">("typing");
  const timeoutRef = useRef<ReturnType<typeof setTimeout>>();

  // Typewriter for outcomes
  useEffect(() => {
    const current = outcomes[idx];
    if (!deleting && displayed.length < current.length) {
      timeoutRef.current = setTimeout(() => setDisplayed(current.slice(0, displayed.length + 1)), 70);
    } else if (!deleting && displayed.length === current.length) {
      timeoutRef.current = setTimeout(() => setDeleting(true), 1700);
    } else if (deleting && displayed.length > 0) {
      timeoutRef.current = setTimeout(() => setDisplayed(displayed.slice(0, -1)), 35);
    } else if (deleting && displayed.length === 0) {
      setDeleting(false);
      setIdx((i) => (i + 1) % outcomes.length);
    }
    return () => clearTimeout(timeoutRef.current);
  }, [displayed, deleting, idx]);

  // Reveal the query line by line, "run" it, then show the result
  useEffect(() => {
    if (phase !== "typing") return;
    if (visibleLines >= queryLines.length) {
      setPhase("running");
      return;
    }
    const t = setTimeout(() => setVisibleLines(v => v + 1), visibleLines === 0 ? 600 : 150);
    return () => clearTimeout(t);
  }, [visibleLines, phase]);

  useEffect(() => {
    if (phase !== "running") return;
    const t = setTimeout(() => setPhase("done"), 700);
    return () => clearTimeout(t);
  }, [phase]);

  return (
    <section id="home" className="relative min-h-screen flex items-center overflow-hidden">

      {/* Mesh gradient background */}
      <div className="absolute inset-0" style={{
        background: "radial-gradient(ellipse 80% 55% at 15% 40%, hsl(168 84% 38% / 0.13) 0%, transparent 55%), radial-gradient(ellipse 65% 50% at 85% 55%, hsl(199 89% 48% / 0.11) 0%, transparent 55%), radial-gradient(ellipse 45% 40% at 50% 95%, hsl(168 84% 55% / 0.07) 0%, transparent 60%)"
      }} />

      {/* Grid lines — like chart gridlines */}
      <div className="absolute inset-0 opacity-[0.35] dark:opacity-[0.25]" style={{
        backgroundImage: "linear-gradient(hsl(var(--border)) 1px, transparent 1px), linear-gradient(90deg, hsl(var(--border)) 1px, transparent 1px)",
        backgroundSize: "56px 56px",
        maskImage: "radial-gradient(ellipse 70% 60% at 50% 45%, black 20%, transparent 75%)",
        WebkitMaskImage: "radial-gradient(ellipse 70% 60% at 50% 45%, black 20%, transparent 75%)",
      }} />

      <div className="hero-orb-1 absolute -top-24 -left-24 w-[520px] h-[520px] rounded-full blur-[130px]" style={{ background: "hsl(168 84% 42% / 0.17)" }} />
      <div className="hero-orb-2 absolute -bottom-32 -right-32 w-[480px] h-[480px] rounded-full blur-[120px]" style={{ background: "hsl(199 89% 48% / 0.14)" }} />

      <div className="relative container mx-auto px-4 md:px-8 max-w-6xl pt-28 pb-16">
        <div className="grid lg:grid-cols-[1.15fr_1fr] gap-12 lg:gap-10 items-center">

          {/* ── Left: intro ── */}
          <div className="text-center lg:text-left">
            <div className="animate-fade-up flex justify-center lg:justify-start mb-6">
              <span className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full text-[11px] font-mono tracking-widest uppercase"
                style={{ background: "hsl(168 84% 38% / 0.1)", border: "1px solid hsl(168 84% 38% / 0.28)", color: "hsl(var(--primary))" }}>
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400" />
                </span>
                Open to Data Analyst roles
              </span>
            </div>

            <h1 className="animate-fade-up animate-delay-100 font-bold leading-[1.02] mb-4 tracking-tight"
              style={{ fontSize: "clamp(2.6rem, 5.8vw, 4.25rem)" }}>
              <span className="block text-muted-foreground/80 font-medium mb-1" style={{ fontSize: "0.4em" }}>Hi, I'm</span>
              <span className="gradient-text">Sarvesh Kumar</span>
              <span className="text-foreground/30 font-semibold whitespace-nowrap" style={{ fontSize: "0.42em" }}> R.M</span>
            </h1>

            <p className="animate-fade-up animate-delay-200 text-2xl md:text-3xl font-semibold tracking-tight mb-3" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              Aspiring <span className="text-primary">Data Analyst</span>
            </p>

            <div className="animate-fade-up animate-delay-200 flex justify-center lg:justify-start mb-5 h-8 items-center font-mono text-base md:text-lg">
              <span className="text-muted-foreground mr-2">raw data →</span>
              <span className="font-semibold text-primary">{displayed}<span className="cursor" /></span>
            </div>

            <p className="animate-fade-up animate-delay-300 text-base md:text-[17px] text-muted-foreground max-w-xl mx-auto lg:mx-0 mb-7 leading-relaxed">
              Computer Science student who queries data with <span className="text-foreground font-medium">SQL</span>,
              cleans and analyses it with <span className="text-foreground font-medium">Python &amp; Pandas</span>, and presents it in
              {" "}<span className="text-foreground font-medium">Power BI &amp; Excel dashboards</span>. Currently doing data analysis,
              visualization and reporting as an intern at VIPS Tech.
            </p>

            <div className="animate-fade-up animate-delay-400 flex flex-wrap gap-3 justify-center lg:justify-start mb-7">
              <a href="#projects"
                className="group inline-flex items-center gap-2 px-6 py-3.5 rounded-2xl text-white font-semibold gradient-bg-vivid hover:opacity-95 transition-all hover:-translate-y-1"
                style={{ boxShadow: "0 10px 30px -6px hsl(168 84% 38% / 0.55)" }}>
                <Sparkles size={17} />
                View Projects
                <span className="group-hover:translate-x-1 transition-transform inline-block">→</span>
              </a>
              <a href={PROFILE.resume} download={PROFILE.resumeFileName}
                className="group inline-flex items-center gap-2 px-6 py-3.5 rounded-2xl border font-semibold bg-card/70 backdrop-blur hover:-translate-y-1 hover:border-primary/50 transition-all">
                <Download size={17} className="group-hover:animate-bounce" />
                Download Resume
              </a>
            </div>

            <div className="animate-fade-up animate-delay-500 flex flex-wrap items-center gap-3 justify-center lg:justify-start">
              {socials.map(s => (
                <a key={s.label} href={s.href} target={s.href.startsWith("http") ? "_blank" : undefined} rel="noopener noreferrer"
                  aria-label={s.label} title={s.label}
                  className="w-10 h-10 rounded-xl border border-border bg-card/70 flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary/50 hover:-translate-y-0.5 transition-all">
                  <s.icon size={17} />
                </a>
              ))}
              <span className="hidden sm:block w-px h-6 bg-border mx-1" />
              <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <MapPin size={13} /> {PROFILE.location}
              </span>
            </div>
          </div>

          {/* ── Right: SQL card ── */}
          <div className="animate-fade-up animate-delay-300 relative max-w-md w-full mx-auto">
            <div className="absolute -inset-4 rounded-[2rem] blur-2xl opacity-40 gradient-bg" />
            <div className="relative rounded-2xl overflow-hidden border border-white/10 shadow-2xl text-left" style={{ background: "hsl(210 30% 9%)" }}>
              {/* title bar */}
              <div className="flex items-center gap-2 px-4 py-3 border-b border-white/10" style={{ background: "hsl(210 28% 12%)" }}>
                <span className="w-3 h-3 rounded-full bg-[#ff5f57]" />
                <span className="w-3 h-3 rounded-full bg-[#febc2e]" />
                <span className="w-3 h-3 rounded-full bg-[#28c840]" />
                <span className="ml-3 font-mono text-[11px] text-white/45">hiring.sql — MySQL</span>
                <span className="ml-auto inline-flex items-center gap-1 font-mono text-[10px] px-2 py-0.5 rounded-md"
                  style={{ background: "hsl(168 84% 38% / 0.18)", color: "hsl(168 84% 62%)" }}>
                  {phase === "running" ? <Loader2 size={10} className="animate-spin" /> : <Play size={10} />}
                  {phase === "running" ? "Running" : "Run"}
                </span>
              </div>

              {/* query */}
              <pre className="font-mono text-[11.5px] sm:text-[12.5px] leading-[1.75] text-white/85 px-4 sm:px-5 py-4 overflow-hidden whitespace-pre">
                {queryLines.map((line, i) => (
                  <div key={i} className="flex transition-all duration-300"
                    style={{ opacity: i < visibleLines ? 1 : 0, transform: i < visibleLines ? "none" : "translateX(-6px)" }}>
                    <span className="w-5 shrink-0 text-right mr-4 text-white/20 select-none">{i + 1}</span>
                    <span>{line}</span>
                  </div>
                ))}
              </pre>

              {/* result */}
              <div className="border-t border-white/10 transition-opacity duration-500" style={{ background: "hsl(210 30% 7%)", opacity: phase === "done" ? 1 : 0.35 }}>
                <div className="flex items-center justify-between px-4 sm:px-5 py-2 border-b border-white/5">
                  <span className="font-mono text-[10px] uppercase tracking-widest text-white/40">Result</span>
                  <span className="font-mono text-[10px] text-white/35">{phase === "done" ? "1 row in set (0.00 sec)" : "…"}</span>
                </div>
                <div className="px-4 sm:px-5 py-3 font-mono text-[11.5px] sm:text-[12px] min-h-[132px]">
                  {resultRows.map(([k, v], i) => (
                    <div key={k} className="grid grid-cols-[88px_1fr] gap-2 py-[3px] transition-all duration-300"
                      style={{ opacity: phase === "done" ? 1 : 0, transform: phase === "done" ? "none" : "translateY(4px)", transitionDelay: `${i * 70}ms` }}>
                      <span className="text-white/40">{k}</span>
                      <span className={k === "role" ? "font-semibold" : "text-white/85"} style={k === "role" ? { color: "hsl(168 84% 60%)" } : undefined}>{v}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* floating chips (hidden on small screens so nothing overflows) */}
            <div className="animate-float hidden sm:flex absolute -right-6 -top-12 glass-card rounded-2xl px-3.5 py-2.5 shadow-xl items-center gap-2.5" style={{ animationDelay: "1.4s" }}>
              <span className="w-8 h-8 rounded-lg gradient-bg flex items-center justify-center text-white"><BarChart3 size={15} /></span>
              <span className="leading-tight">
                <span className="block text-[12px] font-bold">Intern · VIPS Tech</span>
                <span className="block text-[10px] text-muted-foreground">Analysis & reporting</span>
              </span>
            </div>
            <div className="animate-float hidden sm:flex absolute -left-6 -bottom-12 glass-card rounded-2xl px-3.5 py-2.5 shadow-xl items-center gap-2.5">
              <span className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white"><Trophy size={15} /></span>
              <span className="leading-tight">
                <span className="block text-[12px] font-bold">2× Competition Winner</span>
                <span className="block text-[10px] text-muted-foreground">Robotics · IIT Madras hackathon</span>
              </span>
            </div>
          </div>
        </div>

        {/* Stats row */}
        <div className="animate-fade-up animate-delay-600 grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-3xl mx-auto mt-16">
          {stats.map((s, i) => (
            <div key={s.label}
              className="glass-card rounded-2xl py-4 px-3 text-center card-hover pop-in"
              style={{ animationDelay: `${0.7 + i * 0.1}s` }}>
              <div className="text-2xl md:text-3xl font-bold gradient-text mb-0.5" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>{s.value}</div>
              <div className="text-[10px] text-muted-foreground font-mono uppercase tracking-widest">{s.label}</div>
            </div>
          ))}
        </div>

        <div className="flex justify-center mt-10">
          <a href="#about" className="animate-bounce-slow inline-flex flex-col items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors" aria-label="Scroll down">
            <span className="text-[10px] font-mono tracking-widest uppercase">Explore</span>
            <ArrowDown size={18} />
          </a>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
