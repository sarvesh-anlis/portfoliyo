import { Github, Linkedin, Globe, Heart, ArrowUp, Mail } from "lucide-react";
import { useEffect, useState } from "react";
import Logo from "@/components/Logo";
import { PROFILE, mailto } from "@/data/profile";

const Footer = () => {
  const [showTop, setShowTop] = useState(false);
  useEffect(() => {
    const on = () => setShowTop(window.scrollY > 600);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);
  return (
  <footer className="relative border-t border-border overflow-hidden">
    <div className="absolute inset-0 opacity-[0.015]"
      style={{ backgroundImage: "radial-gradient(circle, hsl(168 84% 40%) 1px, transparent 1px)", backgroundSize: "28px 28px" }} />

    <div className="container mx-auto px-4 md:px-8 md:pr-20 py-10 pb-24 md:pb-10 relative">
      <div className="flex flex-col md:flex-row items-center justify-between gap-6">

        <div className="text-center md:text-left">
          <a href="#home" className="group inline-flex justify-center md:justify-start mb-2"><Logo size={36} /></a>
          <p className="text-xs text-muted-foreground">Aspiring Data Analyst · SQL · Python · Power BI · Excel</p>
        </div>

        <div className="flex items-center gap-2">
          {[
            { icon: Github,   href: PROFILE.github,   label: "GitHub",   title: "GitHub"   },
            { icon: Linkedin, href: PROFILE.linkedin, label: "LinkedIn", title: "LinkedIn" },
            { icon: Globe,    href: PROFILE.website,  label: "Website",  title: "Website"  },
            { icon: Mail,     href: mailto,           label: "Email",    title: "Email"    },
          ].map((s) => (
            <a key={s.label} href={s.href} target={s.href.startsWith("http") ? "_blank" : undefined}
              rel="noopener noreferrer" aria-label={s.label} title={s.title}
              className="w-9 h-9 rounded-xl border border-border bg-card flex items-center justify-center hover:border-primary/60 hover:text-primary hover:-translate-y-0.5 transition-all">
              <s.icon size={15} />
            </a>
          ))}
        </div>

        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <span>© 2026 Sarvesh Kumar R.M · Made with</span>
          <Heart size={11} className="text-rose-500 fill-rose-500 animate-shimmer" />
        </div>
      </div>
    </div>

    <button onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      className={`fixed bottom-6 right-6 w-11 h-11 rounded-xl gradient-bg text-white flex items-center justify-center shadow-lg hover:opacity-90 transition-all duration-300 z-40 ${showTop ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4 pointer-events-none"}`}
      style={{ boxShadow: "0 4px 16px hsl(168 84% 38% / 0.4)" }}
      aria-label="Back to top">
      <ArrowUp size={16} />
    </button>
  </footer>
  );
};

export default Footer;
