import { useState } from "react";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import { Mail, Phone, MapPin, Globe, Github, Linkedin, ArrowUpRight, Download, Copy, Check, ExternalLink } from "lucide-react";
import { PROFILE, mailto, gmailCompose } from "@/data/profile";

/** Copy text to the clipboard, with a fallback for older / non-secure browsers. */
const copyText = async (text: string) => {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      document.body.removeChild(ta);
      return ok;
    } catch {
      return false;
    }
  }
};

const socials = [
  { icon: Github, label: "GitHub", sub: PROFILE.githubLabel, href: PROFILE.github, bg: "#24292f" },
  { icon: Linkedin, label: "LinkedIn", sub: PROFILE.linkedinLabel, href: PROFILE.linkedin, bg: "#0A66C2" },
];

const Ring = ({ size, dur, delay, color }: { size: number; dur: number; delay: number; color: string }) => (
  <div className="absolute rounded-full pointer-events-none spin-slow"
    style={{ width: size, height: size, border: `1px solid ${color}`, top: "50%", left: "50%", transform: "translate(-50%,-50%)", animationDuration: `${dur}s`, animationDelay: `${delay}s`, opacity: 0.06 }} />
);

const CopyBtn = ({ value, label }: { value: string; label: string }) => {
  const [copied, setCopied] = useState(false);
  return (
    <button type="button"
      onClick={async () => { if (await copyText(value)) { setCopied(true); setTimeout(() => setCopied(false), 1800); } }}
      className={`inline-flex items-center gap-1 px-2.5 h-8 rounded-lg text-[11px] font-semibold border transition-all shrink-0 ${copied ? "border-emerald-500/40 text-emerald-600 dark:text-emerald-400 bg-emerald-500/10" : "border-border text-muted-foreground hover:text-primary hover:border-primary/40"}`}
      aria-label={`Copy ${label}`}>
      {copied ? <><Check size={13} /> Copied</> : <><Copy size={13} /> Copy</>}
    </button>
  );
};

const ContactSection = () => {
  const { ref, isVisible } = useScrollAnimation();

  const rows = [
    { icon: Mail, label: "Email", value: PROFILE.email, href: mailto, copy: PROFILE.email, extra: { href: gmailCompose, text: "Open in Gmail" } },
    { icon: Phone, label: "Phone", value: PROFILE.phone, href: PROFILE.phoneHref, copy: PROFILE.phone },
    { icon: MapPin, label: "Location", value: PROFILE.location },
    { icon: Globe, label: "Website", value: PROFILE.websiteLabel, href: PROFILE.website },
  ];

  return (
    <section id="contact" className="py-28 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <Ring size={320} dur={22} delay={0} color="hsl(168 84% 45%)" />
        <Ring size={500} dur={30} delay={4} color="hsl(199 89% 50%)" />
        <Ring size={700} dur={40} delay={8} color="hsl(168 84% 40%)" />
        <Ring size={900} dur={55} delay={12} color="hsl(199 89% 45%)" />
      </div>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full blur-[150px] opacity-[0.07] pointer-events-none"
        style={{ background: "linear-gradient(135deg, hsl(168 84% 42%), hsl(199 89% 52%))" }} />

      <div className="container mx-auto px-4 md:px-8 relative" ref={ref}>
        <div className={`transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}>

          <div className="text-center mb-16">
            <span className="section-chip mb-4">Contact</span>
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Let's <span className="gradient-text">Connect</span>
            </h2>
            <p className="text-muted-foreground max-w-lg mx-auto">Hiring for a data analyst role or internship? I'd love to hear from you.</p>
          </div>

          <div className="max-w-4xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8">

            {/* ── Left: availability + contact details ── */}
            <div className="flex flex-col gap-4">
              <div className="rounded-2xl gradient-bg-vivid p-6 text-white relative overflow-hidden shadow-xl"
                style={{ boxShadow: "0 16px 48px hsl(168 84% 38% / 0.35)" }}>
                <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-white/10 blur-xl" />
                <p className="relative text-xs font-mono opacity-75 mb-2 uppercase tracking-widest">Available for</p>
                <p className="relative text-2xl font-bold mb-4 leading-snug">Data Analyst internships<br />&amp; entry-level roles</p>
                <div className="relative flex flex-wrap gap-2 mb-5">
                  {["Data Analysis", "SQL", "Power BI", "Excel Reporting"].map(t => (
                    <span key={t} className="text-xs px-3 py-1 rounded-full bg-white/15 border border-white/20 font-medium">{t}</span>
                  ))}
                </div>
                <a href={PROFILE.resume} download={PROFILE.resumeFileName}
                  className="relative inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white/20 hover:bg-white/30 border border-white/30 text-sm font-semibold transition-all hover:-translate-y-0.5">
                  <Download size={15} /> Download My Resume
                </a>
              </div>

              {rows.map((item) => (
                <div key={item.label} className="flex items-center gap-3.5 p-4 rounded-2xl bg-card border border-border card-hover">
                  <div className="w-10 h-10 rounded-xl gradient-bg flex items-center justify-center shrink-0 shadow-md"
                    style={{ boxShadow: "0 4px 12px hsl(168 84% 38% / 0.3)" }}>
                    <item.icon size={16} className="text-white" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-[10px] text-muted-foreground font-mono uppercase tracking-widest mb-0.5">{item.label}</p>
                    {item.href ? (
                      <a href={item.href} className="text-sm font-semibold hover:text-primary transition-colors break-all"
                        target={item.href.startsWith("http") ? "_blank" : undefined} rel="noopener noreferrer">
                        {item.value}
                      </a>
                    ) : (
                      <p className="text-sm font-semibold">{item.value}</p>
                    )}
                    {item.extra && (
                      <a href={item.extra.href} target="_blank" rel="noopener noreferrer"
                        className="mt-1 inline-flex items-center gap-1 text-[11px] font-medium text-primary hover:underline">
                        {item.extra.text} <ExternalLink size={11} />
                      </a>
                    )}
                  </div>
                  {item.copy && <CopyBtn value={item.copy} label={item.label} />}
                </div>
              ))}
            </div>

            {/* ── Right: social cards + response card ── */}
            <div className="flex flex-col gap-4">
              <p className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-1">Find me on</p>

              {socials.map((s) => (
                <a key={s.label} href={s.href} target="_blank" rel="noopener noreferrer"
                  className="group flex items-center gap-4 p-5 rounded-2xl bg-card border border-border card-hover relative overflow-hidden">
                  <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-lg flex-shrink-0 transition-transform group-hover:scale-110 ring-1 ring-white/10"
                    style={{ background: s.bg }}>
                    <s.icon size={22} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-base mb-0.5">{s.label}</p>
                    <p className="text-xs text-muted-foreground truncate">{s.sub}</p>
                  </div>
                  <ArrowUpRight size={18} className="text-muted-foreground group-hover:text-primary group-hover:-translate-y-0.5 group-hover:translate-x-0.5 transition-all" />
                </a>
              ))}

              <div className="mt-2 rounded-2xl border border-border bg-card p-6 relative overflow-hidden">
                <div className="absolute top-0 left-0 right-0 h-1 gradient-bg rounded-t-2xl" />
                <p className="text-sm font-mono uppercase tracking-widest text-muted-foreground mb-3">Response time</p>
                <p className="text-3xl font-black gradient-text mb-1">≤ 24h</p>
                <p className="text-sm text-muted-foreground">I reply to every message within 24 hours. The fastest way to reach me is email.</p>
                <div className="flex items-center gap-2 mt-4">
                  <span className="relative flex h-2.5 w-2.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-60" />
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-400" />
                  </span>
                  <span className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold">Actively looking</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
