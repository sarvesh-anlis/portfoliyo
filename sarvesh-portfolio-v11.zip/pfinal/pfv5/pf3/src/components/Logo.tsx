import { useId } from "react";

/**
 * Brand mark for Sarvesh Kumar R.M
 * A rounded tile holding an "SK" monogram whose strokes end in small
 * data points — a nod to data pipelines.
 */
type LogoProps = { size?: number; withWordmark?: boolean; className?: string };

export const LogoMark = ({ size = 38 }: { size?: number }) => {
  const uid = useId().replace(/:/g, "");
  return (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" aria-hidden="true" className="shrink-0">
    <defs>
      <linearGradient id={`bg${uid}`} x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">
        <stop offset="0" stopColor="hsl(168 84% 36%)" />
        <stop offset="1" stopColor="hsl(199 89% 46%)" />
      </linearGradient>
      <linearGradient id={`sh${uid}`} x1="0" y1="0" x2="0" y2="48" gradientUnits="userSpaceOnUse">
        <stop offset="0" stopColor="#fff" stopOpacity="0.28" />
        <stop offset="0.5" stopColor="#fff" stopOpacity="0" />
      </linearGradient>
    </defs>
    <rect x="1" y="1" width="46" height="46" rx="13" fill={`url(#bg${uid})`} />
    <rect x="1" y="1" width="46" height="46" rx="13" fill={`url(#sh${uid})`} />
    <rect x="1.5" y="1.5" width="45" height="45" rx="12.5" stroke="#fff" strokeOpacity="0.25" />
    {/* S */}
    <path d="M22 15.5h-6.2a4.3 4.3 0 0 0 0 8.6h2.4a4.3 4.3 0 0 1 0 8.6H11.5"
      stroke="#fff" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" />
    {/* K */}
    <path d="M27 15v18M27 24.5 35 15.5M29.8 21.6 36 33"
      stroke="#fff" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" />
    {/* circuit nodes */}
    <circle cx="22" cy="15.5" r="2.1" fill="hsl(168 90% 80%)" />
    <circle cx="11.5" cy="32.7" r="2.1" fill="hsl(199 95% 82%)" />
    <circle cx="36" cy="33" r="2.1" fill="hsl(168 90% 80%)" />
  </svg>
  );
};

const Logo = ({ size = 38, withWordmark = true, className = "" }: LogoProps) => (
  <span className={`flex items-center gap-2.5 ${className}`}>
    <span className="transition-transform duration-300 group-hover:rotate-[-6deg] group-hover:scale-105"
      style={{ filter: "drop-shadow(0 4px 12px hsl(168 84% 38% / 0.35))" }}>
      <LogoMark size={size} />
    </span>
    {withWordmark && (
      <span className="flex flex-col leading-none">
        <span className="font-bold text-[15px] tracking-tight text-foreground" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
          Sarvesh Kumar<span className="text-primary">.</span>
        </span>
        <span className="font-mono text-[10px] tracking-[0.18em] uppercase text-muted-foreground mt-1">Data Analyst</span>
      </span>
    )}
  </span>
);

export default Logo;
