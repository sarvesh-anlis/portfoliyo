import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import { HelpCircle, DatabaseZap, Eraser, LineChart, Presentation } from "lucide-react";

const steps = [
  { icon: HelpCircle, title: "Ask", desc: "Pin down the business question and the KPIs that will answer it.", tools: ["Stakeholder questions", "KPIs"] },
  { icon: DatabaseZap, title: "Collect", desc: "Pull exactly the data needed with SQL queries or source files.", tools: ["SQL", "MySQL", "Excel"] },
  { icon: Eraser, title: "Clean", desc: "Fix missing values, duplicates and inconsistent formats.", tools: ["Pandas", "Excel"] },
  { icon: LineChart, title: "Analyse", desc: "Aggregate, compare and look for trends, patterns and outliers.", tools: ["Python", "Pandas", "SQL"] },
  { icon: Presentation, title: "Present", desc: "Share the story through dashboards and a short, clear report.", tools: ["Power BI", "Excel", "Reporting"] },
];

const ApproachSection = () => {
  const { ref, isVisible } = useScrollAnimation(0.15);

  return (
    <section id="approach" className="py-28 relative overflow-hidden">
      <div className="absolute -top-20 left-1/2 -translate-x-1/2 w-[600px] h-[300px] rounded-full blur-[140px] opacity-[0.06]"
        style={{ background: "linear-gradient(90deg, hsl(168 84% 45%), hsl(199 89% 50%))" }} />

      <div className="container mx-auto px-4 md:px-8 relative" ref={ref}>
        <div className={`transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}>
          <div className="text-center mb-16">
            <span className="section-chip mb-4">Approach</span>
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              How I Work With <span className="gradient-text">Data</span>
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">From a question to a decision, in five steps</p>
          </div>
        </div>

        <div className="relative max-w-6xl mx-auto">
          {/* connecting line (desktop: horizontal, mobile: vertical) */}
          <div className="hidden lg:block absolute top-7 left-[10%] right-[10%] h-0.5 bg-border overflow-hidden rounded-full">
            <div className="h-full gradient-bg transition-all duration-[1600ms] ease-out" style={{ width: isVisible ? "100%" : "0%", transitionDelay: "300ms" }} />
          </div>
          <div className="lg:hidden absolute top-2 bottom-2 left-7 w-0.5 bg-border overflow-hidden rounded-full">
            <div className="w-full gradient-bg transition-all duration-[1600ms] ease-out" style={{ height: isVisible ? "100%" : "0%", transitionDelay: "300ms" }} />
          </div>

          <ol className="grid grid-cols-1 lg:grid-cols-5 gap-6 lg:gap-5">
            {steps.map((s, i) => (
              <li key={s.title}
                className={`relative flex lg:flex-col items-start lg:items-center gap-4 lg:gap-0 lg:text-center ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
                style={{ transition: "all 0.6s cubic-bezier(0.16,1,0.3,1)", transitionDelay: `${300 + i * 150}ms` }}>
                <div className="relative z-10 shrink-0 w-14 h-14 rounded-2xl gradient-bg flex items-center justify-center text-white shadow-lg lg:mb-5"
                  style={{ boxShadow: "0 8px 24px -6px hsl(168 84% 38% / 0.5)" }}>
                  <s.icon size={22} />
                  <span className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-card border border-border text-[10px] font-mono font-bold text-foreground flex items-center justify-center">
                    {i + 1}
                  </span>
                </div>
                <div className="flex-1 rounded-2xl bg-card border border-border p-4 lg:p-5 card-hover w-full">
                  <h3 className="font-bold text-base mb-1.5">{s.title}</h3>
                  <p className="text-[13px] text-muted-foreground leading-relaxed mb-3">{s.desc}</p>
                  <div className="flex flex-wrap gap-1.5 lg:justify-center">
                    {s.tools.map(t => (
                      <span key={t} className="px-2 py-0.5 text-[10.5px] font-mono rounded-md"
                        style={{ background: "hsl(var(--primary) / 0.08)", color: "hsl(var(--primary))", border: "1px solid hsl(var(--primary) / 0.18)" }}>
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
};

export default ApproachSection;
