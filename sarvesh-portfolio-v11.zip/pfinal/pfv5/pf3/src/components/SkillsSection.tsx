import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import { Database, Table2, PieChart } from "lucide-react";

// The core data-analyst stack — the first thing a recruiter should see
const core = [
  {
    icon: Database,
    step: "Query",
    title: "SQL & Databases",
    desc: "Filter, join and aggregate data to answer business questions.",
    tags: ["SQL", "MySQL"],
    gradient: "from-teal-500 to-emerald-500",
  },
  {
    icon: Table2,
    step: "Clean & analyse",
    title: "Python & Pandas",
    desc: "Clean messy data, reshape it and explore it for trends.",
    tags: ["Python", "Pandas", "Data Cleaning", "Data Analysis"],
    gradient: "from-sky-500 to-cyan-500",
  },
  {
    icon: PieChart,
    step: "Visualise & report",
    title: "Dashboards & Reporting",
    desc: "Turn findings into dashboards and reports people can act on.",
    tags: ["Power BI", "Excel Dashboards", "Data Visualization", "Reporting"],
    gradient: "from-indigo-500 to-sky-500",
  },
];

// Everything else from the resume, still visible but secondary
const supporting = [
  { category: "Machine Learning", icon: "🧠", tags: ["XGBoost", "TF-IDF", "Feature Engineering", "NLP"] },
  { category: "CS Foundations", icon: "⚡", tags: ["Data Structures", "Algorithms"] },
  { category: "Cloud & Data Stores", icon: "☁️", tags: ["Firebase", "Cloud AI", "AI-Based Development"] },
  { category: "Tools & Platforms", icon: "🛠️", tags: ["Git", "VS Code", "Netlify"] },
  { category: "IoT & Hardware", icon: "📡", tags: ["ESP32", "Arduino", "NodeMCU", "Sensors"] },
];

// Edit these to whatever you are actually learning right now
const learning = ["Advanced SQL (window functions)", "DAX in Power BI", "Statistics for analysis"];

const SkillsSection = () => {
  const { ref, isVisible } = useScrollAnimation();
  const fade = (i: number) => ({
    className: isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10",
    style: { transitionDelay: `${i * 80}ms`, transition: "all 0.55s cubic-bezier(0.16,1,0.3,1)" },
  });

  return (
    <section id="skills" className="py-28 relative" style={{ background: "hsl(var(--muted) / 0.35)" }}>
      <div className="absolute inset-0 opacity-[0.02] dark:opacity-[0.03]"
        style={{ backgroundImage: "radial-gradient(circle, hsl(168 84% 38%) 1px, transparent 1px)", backgroundSize: "32px 32px" }} />

      <div className="container mx-auto px-4 md:px-8 relative" ref={ref}>
        <div className={`transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}>
          <div className="text-center mb-14">
            <span className="section-chip mb-4">Toolkit</span>
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Analyst <span className="gradient-text">Toolkit</span>
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">The tools I use at each step of an analysis</p>
          </div>
        </div>

        {/* Core stack */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 max-w-6xl mx-auto mb-12">
          {core.map((c, i) => {
            const f = fade(i);
            return (
              <div key={c.title} className={`group relative rounded-2xl bg-card border border-border card-hover overflow-hidden ${f.className}`} style={f.style}>
                <div className={`h-1 w-full bg-gradient-to-r ${c.gradient}`} />
                <div className="p-6">
                  <div className="flex items-center justify-between mb-5">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${c.gradient} flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform`}>
                      <c.icon size={22} className="text-white" />
                    </div>
                    <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                      {String(i + 1).padStart(2, "0")} · {c.step}
                    </span>
                  </div>
                  <h3 className="text-lg font-bold mb-1.5">{c.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed mb-5">{c.desc}</p>
                  <div className="flex flex-wrap gap-2">
                    {c.tags.map((t) => (
                      <span key={t} className="px-3 py-1.5 text-xs font-semibold rounded-full"
                        style={{ background: "hsl(var(--primary) / 0.1)", color: "hsl(var(--primary))", border: "1px solid hsl(var(--primary) / 0.22)" }}>
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Supporting skills */}
        <div className="max-w-6xl mx-auto">
          <p className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground mb-4 text-center md:text-left">Also in my toolkit</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {supporting.map((g, i) => {
              const f = fade(i + 3);
              return (
                <div key={g.category} className={`rounded-2xl bg-card/80 border border-border p-5 card-hover ${f.className}`} style={f.style}>
                  <div className="flex items-center gap-2.5 mb-3">
                    <span className="text-base">{g.icon}</span>
                    <p className="font-semibold text-sm">{g.category}</p>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {g.tags.map((t) => (
                      <span key={t} className="px-2.5 py-1 text-[11px] font-medium rounded-full bg-muted text-muted-foreground border border-border">{t}</span>
                    ))}
                  </div>
                </div>
              );
            })}

            {(() => {
              const f = fade(supporting.length + 3);
              return (
                <div className={`rounded-2xl gradient-bg-vivid p-5 flex flex-col justify-between card-hover ${f.className}`} style={f.style}>
                  <p className="text-white/70 font-mono text-[11px] uppercase tracking-widest mb-3">Currently learning</p>
                  <div className="flex flex-wrap gap-1.5">
                    {learning.map(t => (
                      <span key={t} className="px-2.5 py-1 text-[11px] font-medium rounded-full bg-white/15 text-white border border-white/25">{t}</span>
                    ))}
                  </div>
                  <p className="text-white/60 text-xs mt-3 font-mono">Always expanding →</p>
                </div>
              );
            })()}
          </div>
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
