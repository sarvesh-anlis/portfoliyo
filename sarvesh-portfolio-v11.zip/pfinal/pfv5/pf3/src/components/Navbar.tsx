import { useState, useEffect } from "react";
import { Menu, X, Sun, Moon, FileDown } from "lucide-react";
import Logo from "@/components/Logo";
import { PROFILE } from "@/data/profile";

const navLinks = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Skills", href: "#skills" },
  { label: "Experience", href: "#experience" },
  { label: "Projects", href: "#projects" },
  { label: "Contact", href: "#contact" },
];

const getInitialDark = () => {
  try {
    const saved = localStorage.getItem("theme");
    if (saved) return saved === "dark";
  } catch { /* storage unavailable */ }
  return typeof window !== "undefined" && window.matchMedia?.("(prefers-color-scheme: dark)").matches;
};

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [progress, setProgress] = useState(0);
  const [isDark, setIsDark] = useState<boolean>(getInitialDark);
  const [activeSection, setActiveSection] = useState("home");

  useEffect(() => {
    document.documentElement.classList.toggle("dark", isDark);
    try { localStorage.setItem("theme", isDark ? "dark" : "light"); } catch { /* ignore */ }
  }, [isDark]);

  useEffect(() => {
    const onScroll = () => {
      const y = window.scrollY;
      setScrolled(y > 30);
      const max = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(max > 0 ? Math.min(100, (y / max) * 100) : 0);
      const ids = navLinks.map(l => l.href.slice(1)).reverse();
      for (const s of ids) {
        const el = document.getElementById(s);
        if (el && y >= el.offsetTop - 120) { setActiveSection(s); break; }
      }
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = isOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [isOpen]);

  const ThemeBtn = (
    <button onClick={() => setIsDark(d => !d)}
      className="w-10 h-10 rounded-xl bg-muted/70 hover:bg-muted border border-border/60 flex items-center justify-center transition-all hover:rotate-12"
      aria-label={isDark ? "Switch to light mode" : "Switch to dark mode"}>
      {isDark ? <Sun size={16} /> : <Moon size={16} />}
    </button>
  );

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? "glass shadow-[0_4px_30px_-12px_rgba(0,0,0,0.12)]" : "bg-transparent"}`}>
      <div className="container mx-auto px-4 md:px-8">
        <div className={`flex items-center justify-between transition-all duration-300 ${scrolled ? "h-16" : "h-20"}`}>

          <a href="#home" className="group" aria-label="Sarvesh Kumar — home">
            <Logo size={scrolled ? 36 : 40} />
          </a>

          {/* Desktop nav */}
          <div className="hidden lg:flex items-center gap-1 p-1 rounded-2xl bg-card/60 border border-border/60 backdrop-blur-md">
            {navLinks.map((link) => {
              const active = activeSection === link.href.slice(1);
              return (
                <a key={link.href} href={link.href}
                  className={`relative px-3.5 py-2 rounded-xl text-[13px] font-medium transition-all duration-200 ${active ? "text-white" : "text-muted-foreground hover:text-foreground"}`}>
                  {active && <span className="absolute inset-0 rounded-xl gradient-bg shadow-md" style={{ boxShadow: "0 4px 14px hsl(168 84% 38% / 0.35)" }} />}
                  <span className="relative">{link.label}</span>
                </a>
              );
            })}
          </div>

          <div className="hidden lg:flex items-center gap-2">
            {ThemeBtn}
            <a href={PROFILE.resume} download={PROFILE.resumeFileName}
              className="inline-flex items-center gap-1.5 px-3.5 h-10 rounded-xl border border-border bg-card/70 text-[13px] font-semibold hover:border-primary/50 hover:text-primary transition-colors">
              <FileDown size={15} /> Resume
            </a>
            <a href="#contact" className="inline-flex items-center px-4 h-10 rounded-xl gradient-bg text-white text-[13px] font-semibold hover:opacity-90 transition-all hover:-translate-y-0.5 shadow-sm">
              Hire Me
            </a>
          </div>

          {/* Mobile toggle */}
          <div className="flex lg:hidden items-center gap-2">
            {ThemeBtn}
            <button onClick={() => setIsOpen(!isOpen)} className="w-10 h-10 rounded-xl bg-muted/70 border border-border/60 flex items-center justify-center" aria-label="Menu" aria-expanded={isOpen}>
              {isOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>

        {isOpen && (
          <div className="lg:hidden glass rounded-2xl mb-3 p-3 space-y-1 border border-border animate-fade-in">
            {navLinks.map((link) => (
              <a key={link.href} href={link.href} onClick={() => setIsOpen(false)}
                className={`block px-4 py-3 rounded-xl text-sm font-medium transition-colors ${activeSection === link.href.slice(1) ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground hover:bg-muted/60"}`}>
                {link.label}
              </a>
            ))}
            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-border mt-1">
              <a href={PROFILE.resume} download={PROFILE.resumeFileName} onClick={() => setIsOpen(false)}
                className="flex items-center justify-center gap-1.5 px-4 py-3 rounded-xl text-sm font-semibold border border-border">
                <FileDown size={15} /> Resume
              </a>
              <a href="#contact" onClick={() => setIsOpen(false)}
                className="block px-4 py-3 rounded-xl text-sm font-semibold text-center gradient-bg text-white">
                Hire Me
              </a>
            </div>
          </div>
        )}
      </div>

      {/* Scroll progress */}
      <div className="absolute left-0 bottom-0 h-[2px] gradient-bg transition-[width] duration-150" style={{ width: `${progress}%` }} />
    </nav>
  );
};

export default Navbar;
