import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import { Briefcase, GraduationCap, CalendarDays, CheckCircle2, Trophy, Star } from "lucide-react";

const ExperienceSection = () => {
  const { ref, isVisible } = useScrollAnimation();
  return (
    <section id="experience" className="py-28 relative overflow-hidden">
      <div className="absolute bottom-0 left-0 w-[350px] h-[350px] rounded-full blur-[120px] opacity-5"
        style={{ background: "hsl(199 89% 48%)" }} />

      <div className="container mx-auto px-4 md:px-8" ref={ref}>
        <div className={`transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}>

          <div className="text-center mb-16">
            <span className="section-chip mb-4">Background</span>
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Experience & <span className="gradient-text">Education</span>
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 max-w-6xl mx-auto">

            {/* ── Internship ── */}
            <div className="lg:col-span-4">
              <div className="flex items-center gap-2 mb-5">
                <div className="w-7 h-7 rounded-lg gradient-bg flex items-center justify-center">
                  <Briefcase size={14} className="text-white" />
                </div>
                <h3 className="text-sm font-bold uppercase tracking-widest text-muted-foreground">Internship</h3>
              </div>

              <div className="relative">
                <div className="absolute left-0 top-2 bottom-2 w-0.5 rounded-full gradient-bg opacity-40" />
                <div className="pl-5">
                  <div className="relative rounded-2xl bg-card border border-border p-6 card-hover overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 rounded-full blur-3xl opacity-5 gradient-bg" />

                    <div className="w-12 h-12 rounded-xl gradient-bg flex items-center justify-center mb-4 text-white font-bold text-lg shadow-lg">VT</div>

                    <p className="font-bold text-base mb-0.5">Associate Engineering Intern</p>
                    <p className="text-sm font-semibold text-primary mb-1 font-mono">VIPS Tech</p>
                    <div className="flex items-center gap-1.5 mb-5">
                      <span className="flex h-2 w-2 rounded-full bg-green-400 animate-pulse" />
                      <span className="text-xs text-muted-foreground font-mono">Present</span>
                    </div>

                    <ul className="space-y-3 mb-5">
                      {[
                        <><span className="text-foreground font-medium">Performed data analysis, visualization, and reporting</span></>,
                        <>Developed software solutions using Python and data-driven approaches</>,
                        <>Collaborated on application development and debugging</>,
                      ].map((b, i) => (
                        <li key={i} className="flex items-start gap-2.5 text-sm text-muted-foreground leading-relaxed">
                          <CheckCircle2 size={15} className="text-primary mt-0.5 shrink-0" />
                          <span>{b}</span>
                        </li>
                      ))}
                    </ul>

                    <div className="flex flex-wrap gap-1.5 pt-4 border-t border-border">
                      {["Data Analysis", "Visualization", "Reporting", "Python"].map(t => (
                        <span key={t} className="px-2.5 py-0.5 text-[11px] font-mono rounded-md"
                          style={{ background: "hsl(var(--primary) / 0.08)", color: "hsl(var(--primary))", border: "1px solid hsl(var(--primary) / 0.18)" }}>
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* ── Education ── */}
            <div className="lg:col-span-4">
              <div className="flex items-center gap-2 mb-5">
                <div className="w-7 h-7 rounded-lg gradient-bg flex items-center justify-center">
                  <GraduationCap size={14} className="text-white" />
                </div>
                <h3 className="text-sm font-bold uppercase tracking-widest text-muted-foreground">Education</h3>
              </div>

              <div className="space-y-3">
                {[
                  { degree: "B.E — Computer Science & Engineering", school: "CK College of Engineering and Technology", score: "CGPA 7.3", period: "2023–2027", special: false },
                  { degree: "Class XII — HSC", school: "CK School of Practical Knowledge", score: "62.2%", period: "2023", special: false },
                  { degree: "Class X — SSLC", school: "CK School of Practical Knowledge", score: "100%", period: "2021", special: true },
                ].map((edu, i) => (
                  <div key={i} className="relative group rounded-2xl bg-card border border-border p-4 card-hover overflow-hidden">
                    {edu.special && (
                      <div className="absolute top-3 right-3">
                        <Star size={14} className="text-amber-400 fill-amber-400" />
                      </div>
                    )}
                    <p className="font-bold text-sm mb-0.5 pr-5">{edu.degree}</p>
                    <p className="text-xs text-muted-foreground mb-3">{edu.school}</p>
                    <div className="flex items-center justify-between">
                      <span className={`font-mono text-xs px-3 py-1 rounded-full font-semibold ${edu.special ? "bg-emerald-500/15 text-emerald-500 border border-emerald-500/25" : "bg-primary/10 text-primary border border-primary/20"}`}>
                        {edu.score}
                      </span>
                      {edu.period && <span className="text-[11px] text-muted-foreground font-mono">{edu.period}</span>}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* ── Achievements + Workshop ── */}
            <div className="lg:col-span-4">
              <div className="flex items-center gap-2 mb-5">
                <div className="w-7 h-7 rounded-lg gradient-bg flex items-center justify-center">
                  <Trophy size={14} className="text-white" />
                </div>
                <h3 className="text-sm font-bold uppercase tracking-widest text-muted-foreground">Achievements</h3>
              </div>

              <div className="space-y-3 mb-6">
                {[
                  { emoji: "🏆", title: "First Prize — RAAIF National Level Robotics Competition", org: "Held at Anna University", color: "from-amber-500 to-yellow-500" },
                  { emoji: "🥇", title: "Winner — Turbo Tech Hackathon", org: "Conducted by PLAS, IIT Madras", color: "from-blue-500 to-indigo-500" },
                ].map((a, i) => (
                  <div key={i} className="rounded-2xl bg-card border border-border p-4 flex gap-3 items-start card-hover">
                    <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${a.color} flex items-center justify-center text-xl flex-shrink-0 shadow-md`}>
                      {a.emoji}
                    </div>
                    <div>
                      <p className="text-sm font-bold leading-snug">{a.title}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{a.org}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex items-center gap-2 mb-5">
                <div className="w-7 h-7 rounded-lg gradient-bg flex items-center justify-center">
                  <CalendarDays size={14} className="text-white" />
                </div>
                <h3 className="text-sm font-bold uppercase tracking-widest text-muted-foreground">Workshop</h3>
              </div>

              <div className="rounded-2xl overflow-hidden border border-border card-hover">
                <div className="gradient-bg-vivid px-5 py-4">
                  <p className="text-white font-bold text-base">TechFest 2026</p>
                  <p className="text-white/70 text-xs mt-0.5">National Level Technical Conference</p>
                </div>
                <div className="bg-card px-5 py-3 flex items-center justify-between">
                  <p className="text-xs text-muted-foreground">Ocean Academy, Puducherry</p>
                  <span className="font-mono text-xs px-2.5 py-1 rounded-full bg-primary/10 text-primary border border-primary/20">Mar 2026</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ExperienceSection;
