import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import { GraduationCap, Briefcase, MapPin, Target, Trophy, ArrowRight } from "lucide-react";
import { PROFILE } from "@/data/profile";

// What I do, framed as data-analyst transformations
const transforms = [
  { from: "A business question", to: "The right SQL query", tools: "SQL · MySQL" },
  { from: "Messy, raw data", to: "A clean, reliable dataset", tools: "Python · Pandas · Excel" },
  { from: "Rows of numbers", to: "Dashboards & clear reports", tools: "Power BI · Excel dashboards" },
];

const facts = [
  { icon: Target, label: "Looking for", value: "Data Analyst internships & entry-level roles" },
  { icon: Briefcase, label: "Currently", value: "Associate Engineering Intern · VIPS Tech" },
  { icon: GraduationCap, label: "Education", value: "B.E. Computer Science & Engineering · 2023–2027 · CGPA 7.3" },
  { icon: Trophy, label: "Wins", value: "RAAIF Robotics (1st) · Turbo Tech Hackathon, IIT Madras" },
  { icon: MapPin, label: "Based in", value: PROFILE.location },
];

const AboutSection = () => {
  const { ref, isVisible } = useScrollAnimation();
  const reveal = (delay: number) => ({
    className: `transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`,
    style: { transitionDelay: `${delay}ms` },
  });

  return (
    <section id="about" className="py-28 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-[400px] h-[400px] rounded-full blur-[140px] opacity-5" style={{ background: "hsl(168 84% 45%)" }} />

      <div className="container mx-auto px-4 md:px-8" ref={ref}>
        <div {...reveal(0)} >
          <div className="text-center mb-14">
            <span className="section-chip mb-4">About Me</span>
            <h2 className="text-4xl md:text-5xl font-bold">
              Who I <span className="gradient-text">Am</span>
            </h2>
          </div>
        </div>

        <div className="grid lg:grid-cols-[1.35fr_1fr] gap-8 max-w-6xl mx-auto items-start">

          {/* Left: story + transformations */}
          <div {...reveal(120)}>
            <div className="space-y-4 text-muted-foreground text-base md:text-[17px] leading-relaxed mb-8">
              <p>
                I'm a Computer Science student at CK College of Engineering and Technology who wants to work as a
                {" "}<span className="text-foreground font-semibold">data analyst</span>. What I enjoy most is the path from a raw
                spreadsheet to a clear answer someone can act on.
              </p>
              <p>
                I write <span className="text-foreground font-medium">SQL</span> to pull the right data, clean and explore it with
                {" "}<span className="text-foreground font-medium">Python and Pandas</span>, and present what I find in
                {" "}<span className="text-foreground font-medium">Power BI and Excel dashboards</span>. As an Associate Engineering
                Intern at VIPS Tech, I perform data analysis, visualization and reporting.
              </p>
            </div>

            <p className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground mb-3">What I do</p>
            <div className="space-y-3">
              {transforms.map((t, i) => (
                <div key={t.to}
                  className={`group grid grid-cols-[1fr_auto_1fr] items-center gap-3 rounded-2xl bg-card border border-border p-3 sm:p-4 card-hover ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-6"}`}
                  style={{ transition: "all 0.6s cubic-bezier(0.16,1,0.3,1)", transitionDelay: `${250 + i * 110}ms` }}>
                  <span className="text-sm text-muted-foreground px-3 py-2 rounded-xl bg-muted/60 text-center">{t.from}</span>
                  <span className="w-8 h-8 rounded-full gradient-bg flex items-center justify-center text-white shadow-md group-hover:translate-x-0.5 transition-transform">
                    <ArrowRight size={15} />
                  </span>
                  <span className="text-center">
                    <span className="block text-sm font-semibold text-foreground">{t.to}</span>
                    <span className="block font-mono text-[10.5px] text-primary mt-0.5">{t.tools}</span>
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Right: quick facts */}
          <div {...reveal(220)}>
            <div className="relative rounded-2xl bg-card border border-border overflow-hidden shadow-sm">
              <div className="h-1 gradient-bg" />
              <div className="p-6">
                <p className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground mb-5">Quick facts</p>
                <ul className="space-y-4">
                  {facts.map((f) => (
                    <li key={f.label} className="flex gap-3.5 items-start">
                      <span className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
                        style={{ background: "hsl(var(--primary) / 0.1)", color: "hsl(var(--primary))" }}>
                        <f.icon size={16} />
                      </span>
                      <span className="min-w-0">
                        <span className="block text-[10px] font-mono uppercase tracking-widest text-muted-foreground">{f.label}</span>
                        <span className="block text-sm font-semibold leading-snug mt-0.5">{f.value}</span>
                      </span>
                    </li>
                  ))}
                </ul>
                <a href={PROFILE.resume} download={PROFILE.resumeFileName}
                  className="mt-6 flex items-center justify-center gap-2 w-full py-3 rounded-xl gradient-bg text-white text-sm font-semibold hover:opacity-90 transition-opacity">
                  Download full resume (PDF)
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
