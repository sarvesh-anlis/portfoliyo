import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import { Github, BrainCircuit, FileSpreadsheet, Droplets, Home, ArrowUpRight, ChevronRight } from "lucide-react";

/**
 * To show "Code" / "Live Demo" buttons on a project, paste the URL into
 * `github` / `demo`. Empty strings keep the buttons hidden (no dead links).
 */
type Project = {
  title: string;
  tagline: string;
  bullets: string[];
  tech: string[];
  shows: string;          // the data-analyst skills this project demonstrates
  github: string;
  demo: string;
};

const featured: Project & { pipeline: string[] } = {
  title: "AI Content Detection Model",
  tagline: "A text-classification pipeline that labels writing as AI-generated or human-written.",
  pipeline: ["Raw text", "Clean & preprocess", "TF-IDF features", "XGBoost model", "AI / Human"],
  bullets: [
    "Performed data preprocessing and feature engineering to improve model accuracy",
    "Applied TF-IDF vectorization to turn raw text into numeric features",
    "Trained XGBoost models to classify AI vs. human-written content",
  ],
  tech: ["Python", "NLP", "TF-IDF", "XGBoost", "Scikit-learn"],
  shows: "Data cleaning · Feature engineering · Classification",
  github: "",
  demo: "",
};

const secondary: Project = {
  title: "AI-Based Question Paper Generator",
  tagline: "Turns syllabus input into a structured, exam-ready question paper, automatically.",
  bullets: [
    "Generates structured question papers from syllabus input",
    "Formats output with proper sections, headings and exam patterns",
    "Automated end-to-end with Python and document-generation tools",
  ],
  tech: ["Python", "Document Automation"],
  shows: "Automated, structured reporting",
  github: "",
  demo: "",
};

const hardware = [
  {
    icon: Droplets,
    title: "IoT Smart Irrigation System",
    desc: "Reads soil-moisture sensor data in real time and switches the water pump automatically; status shown on LCD / web.",
    tech: ["ESP32", "Soil Moisture Sensor", "Automation"],
    gradient: "from-emerald-500 to-teal-500",
  },
  {
    icon: Home,
    title: "Smart Home System",
    desc: "YOLOv8 person/object detection with Firebase real-time data sync and ESP32 relay control of appliances.",
    tech: ["YOLOv8", "Python", "Firebase", "ESP32"],
    gradient: "from-orange-500 to-amber-500",
  },
];

const Tag = ({ t }: { t: string }) => (
  <span className="px-2.5 py-0.5 text-[11px] font-mono rounded-md"
    style={{ background: "hsl(var(--primary) / 0.08)", color: "hsl(var(--primary))", border: "1px solid hsl(var(--primary) / 0.15)" }}>
    {t}
  </span>
);

const Links = ({ p }: { p: Project }) =>
  p.github || p.demo ? (
    <div className="flex items-center gap-4 pt-4 mt-auto border-t border-border">
      {p.github && (
        <a href={p.github} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors">
          <Github size={13} /> Code
        </a>
      )}
      {p.demo && (
        <a href={p.demo} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 text-xs font-medium text-primary hover:opacity-80 ml-auto">
          Live Demo <ArrowUpRight size={13} />
        </a>
      )}
    </div>
  ) : null;

const Shows = ({ text }: { text: string }) => (
  <p className="text-[11px] font-mono text-muted-foreground mb-4">
    <span className="uppercase tracking-widest text-[10px] mr-1.5">Shows:</span>
    <span className="text-foreground/80">{text}</span>
  </p>
);

const ProjectsSection = () => {
  const { ref, isVisible } = useScrollAnimation();
  const fade = (i: number) => ({
    className: isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10",
    style: { transition: "all 0.6s cubic-bezier(0.16,1,0.3,1)", transitionDelay: `${150 + i * 120}ms` },
  });

  return (
    <section id="projects" className="py-28 relative" style={{ background: "hsl(var(--muted) / 0.3)" }}>
      <div className="absolute top-0 right-0 w-[300px] h-[300px] rounded-full blur-[100px] opacity-5" style={{ background: "hsl(168 84% 45%)" }} />

      <div className="container mx-auto px-4 md:px-8" ref={ref}>
        <div className={`transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}>
          <div className="text-center mb-14">
            <span className="section-chip mb-4">Work</span>
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Featured <span className="gradient-text">Projects</span>
            </h2>
            <p className="text-muted-foreground max-w-lg mx-auto">Data &amp; machine-learning work first, plus the hardware I've built along the way</p>
          </div>
        </div>

        <div className="max-w-6xl mx-auto">
          <p className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground mb-4 text-center lg:text-left">Data &amp; Machine Learning</p>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 mb-14">
            {/* Featured */}
            {(() => { const f = fade(0); return (
            <article className={`lg:col-span-3 group relative rounded-2xl bg-card border border-border overflow-hidden flex flex-col card-hover ${f.className}`} style={f.style}>
              <div className="relative bg-gradient-to-br from-teal-600 via-cyan-600 to-sky-600 p-6 overflow-hidden">
                <div className="absolute inset-0 opacity-30" style={{ backgroundImage: "radial-gradient(circle at 15% 40%, rgba(255,255,255,0.18) 0%, transparent 50%)" }} />
                <div className="relative flex items-center gap-3 mb-5">
                  <span className="w-11 h-11 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center border border-white/30">
                    <BrainCircuit size={22} className="text-white" />
                  </span>
                  <span className="font-mono text-[10px] uppercase tracking-widest text-white/80 px-2.5 py-1 rounded-full bg-white/15 border border-white/20">Featured · ML &amp; NLP</span>
                </div>
                {/* pipeline */}
                <ol className="relative flex flex-wrap items-center gap-y-2 gap-x-1.5" aria-label="Project pipeline">
                  {featured.pipeline.map((s, i) => (
                    <li key={s} className="flex items-center gap-1.5">
                      <span className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold border ${i === featured.pipeline.length - 1 ? "bg-white text-teal-700 border-white" : "bg-white/15 text-white border-white/25"}`}>{s}</span>
                      {i < featured.pipeline.length - 1 && <ChevronRight size={14} className="text-white/60" />}
                    </li>
                  ))}
                </ol>
              </div>
              <div className="p-6 flex flex-col flex-1">
                <h3 className="text-xl font-bold mb-2">{featured.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed mb-4">{featured.tagline}</p>
                <ul className="space-y-2 mb-5">
                  {featured.bullets.map((b) => (
                    <li key={b} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <span className="mt-2 w-1.5 h-1.5 rounded-full gradient-bg shrink-0" />{b}
                    </li>
                  ))}
                </ul>
                <Shows text={featured.shows} />
                <div className="flex flex-wrap gap-1.5 mb-5">{featured.tech.map(t => <Tag key={t} t={t} />)}</div>
                <Links p={featured} />
              </div>
            </article>
            ); })()}

            {/* Secondary data project */}
            {(() => { const f = fade(1); return (
            <article className={`lg:col-span-2 group relative rounded-2xl bg-card border border-border overflow-hidden flex flex-col card-hover ${f.className}`} style={f.style}>
              <div className="relative h-24 bg-gradient-to-br from-indigo-500 via-sky-500 to-cyan-500 p-5 flex items-end overflow-hidden">
                <span className="absolute top-3 right-4 font-black text-5xl text-white/20 leading-none">02</span>
                <span className="w-11 h-11 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center border border-white/30">
                  <FileSpreadsheet size={22} className="text-white" />
                </span>
              </div>
              <div className="p-6 flex flex-col flex-1">
                <h3 className="text-lg font-bold mb-2">{secondary.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed mb-4">{secondary.tagline}</p>
                <ul className="space-y-2 mb-5">
                  {secondary.bullets.map((b) => (
                    <li key={b} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <span className="mt-2 w-1.5 h-1.5 rounded-full gradient-bg shrink-0" />{b}
                    </li>
                  ))}
                </ul>
                <Shows text={secondary.shows} />
                <div className="flex flex-wrap gap-1.5 mb-5">{secondary.tech.map(t => <Tag key={t} t={t} />)}</div>
                <Links p={secondary} />
              </div>
            </article>
            ); })()}
          </div>

          {/* Hardware — secondary */}
          <p className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground mb-4 text-center lg:text-left">Also built · IoT &amp; Hardware</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {hardware.map((h, i) => {
              const f = fade(i + 2);
              return (
                <article key={h.title} className={`flex gap-4 items-start rounded-2xl bg-card/80 border border-border p-5 card-hover ${f.className}`} style={f.style}>
                  <span className={`w-11 h-11 rounded-xl bg-gradient-to-br ${h.gradient} flex items-center justify-center text-white shrink-0 shadow-md`}>
                    <h.icon size={20} />
                  </span>
                  <div className="min-w-0">
                    <h3 className="font-bold text-base mb-1">{h.title}</h3>
                    <p className="text-[13px] text-muted-foreground leading-relaxed mb-3">{h.desc}</p>
                    <div className="flex flex-wrap gap-1.5">
                      {h.tech.map(t => (
                        <span key={t} className="px-2 py-0.5 text-[10.5px] font-mono rounded-md bg-muted text-muted-foreground border border-border">{t}</span>
                      ))}
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;
